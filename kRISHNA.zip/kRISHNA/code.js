onEvent("button1", "click", function( ) {
  setScreen("screen2");
});
onEvent("button2", "click", function( ) {
  setScreen("screen3");
});
onEvent("button3", "click", function( ) {
  setScreen("screen3");
});
onEvent("button4", "click", function( ) {
  setScreen("screen3");
});
onEvent("button5", "click", function( ) {
  setScreen("screen3");
});
onEvent("button6", "click", function( ) {
  setScreen("screen4");
});
onEvent("button7", "click", function( ) {
  setScreen("screen4");
});
onEvent("button8", "click", function( ) {
  setScreen("screen4");
});
onEvent("button9", "click", function( ) {
  setScreen("screen5");
});
onEvent("button10", "click", function( ) {
  setScreen("screen5");
});
onEvent("button11", "click", function( ) {
  setScreen("screen5");
});
onEvent("button12", "click", function( ) {
  setScreen("screen5");
});
onEvent("button13", "click", function( ) {
  setScreen("screen6");
});
onEvent("button14", "click", function( ) {
  setScreen("screen6");
});
onEvent("button15", "click", function( ) {
  setScreen("screen6");
});
onEvent("button16", "click", function( ) {
  setScreen("screen6");
});
onEvent("button18", "click", function( ) {
  setScreen("screen7");
});
onEvent("button19", "click", function( ) {
  setScreen("screen8");
});
